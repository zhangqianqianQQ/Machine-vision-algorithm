function num = cpu_cores()
    num = feature('numcores');
end