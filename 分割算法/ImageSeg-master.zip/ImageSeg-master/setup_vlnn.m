% set up vlnn
%setup matconvnet
run /home/spc-public/Yixuan/matconvnet/matconvnet-1.0-beta24/matlab/vl_setupnn;