function ret = sq(mat)
    
    
end